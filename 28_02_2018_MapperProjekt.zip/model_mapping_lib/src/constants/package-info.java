/**
 * This package contains constants for the JavaScript code in the function nodes
 */
package constants;

