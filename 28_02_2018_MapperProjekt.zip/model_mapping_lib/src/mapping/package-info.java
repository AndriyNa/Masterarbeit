/**
 * Contains the main functionality of the mapping
 */
package mapping;

