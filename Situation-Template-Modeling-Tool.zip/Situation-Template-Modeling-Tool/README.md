SitTempModelingTool
===================

This module allows the modelling of Situation Templates and exporting the corresponding XML file.

How to run
==========

1. Install Tomcat
2. Build this module (`ant`)
3. Install the SitTempModelingTool.war in your server
    - Either via Admin Page
    - Or via copying the war file in the data directory of your server (Tomcat8 default: /var/lib/tomcat8/webapps) and the java classes into the WebApp directory (Tomcat8 default: /var/lib/tomcat8/webapps/SitTempModelingTool)
4. Visit the webapp in your browser (Tomcat8 default: http://localhost:8080/SitTempModelingTool)