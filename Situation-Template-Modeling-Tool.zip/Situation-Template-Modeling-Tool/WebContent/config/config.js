/**
 * Created by armin on 31.01.16.
 */
config = '[{
    "server": 'localhost',
    "port": '5984',
    "protocol": 'http'
}]';
