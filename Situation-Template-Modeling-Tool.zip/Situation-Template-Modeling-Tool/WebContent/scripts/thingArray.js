//var thingAppendCounter = 0;

/*
Method to get the thingTypes that are allowed in current template.
 */
function getThingTypes(template, element){
	
	var availableThingTypes = new Array ();
	if (template != ""){
		$.ajax({
		    type: "GET",
		    url: 'http://localhost:5984/situationtemplates/' + template,
		    async: false,
		        success : function(data){
		            var data = JSON.parse(data);
		            availableThingTypes = data.thingTypes;
		        }
		});
	}else{
		console.log ("No things in DB.")
	}
	// BAD STYLE
	$("#thingChoice").empty();
	checkThings(availableThingTypes, element);
}


	
	function createThingOption(type, text, value) {        
		var opt = document.createElement('option');
		opt.value = value;
		opt.text = text;
		type.options.add(opt);
	}

/*
Method to gather all things with thingTypes from inputArray
 */
function checkThings(thingTypeArray, element){
	var thingArray = new Array ();
		$.ajax({
		    type: "GET",
		    url: 'http://localhost:5984/things/_all_docs',
        	async: false,
            success : function(data){
                var data = JSON.parse(data);
                $.each(data.rows, function(i, v) {
                	$.ajax({
					    type: "GET",
					    url: 'http://localhost:5984/things/' + v.id,
			        	async: false,
			        	success : function(data){
			        		var data = JSON.parse(data);
			        		for (var i = 0; i < thingTypeArray.length; i++) {
	                			if (thingTypeArray[i] == data.thingType){
	                    			thingArray.push(data._id);
	                    		}
	                    	}
	               		return;}
            		});

                return
                });
            }
        });

//	if (!thingAppendCounter>0){
		for (var i = 0; i < thingArray.length; i++) {
			createThingOption(element, thingArray[i], thingArray[i]);
		}
	//}

//	thingAppendCounter++;



}