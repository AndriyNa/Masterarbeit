/**
 * Created by armin on 21.11.15.
 */
function validate() {
    var errors = [];
    var starts = [];
    var ends = [];
    var connections = jsPlumb.getConnections();
    // iterate over all connections
    for (var i = 0; i < connections.length; i++) {
        var connection = connections[i];
        var start = connection.sourceId;
        starts.push(start);
        var end = connection.targetId;
        ends.push(end);

        // Context -> Situation
        if (start.startsWith("Context") && !end.startsWith("Operation") 
            && $("#" + start).children()[0].getAttribute("inputtype") != "situation"){
            console.log(start + " -> " + end + " | " + $("#" + start).children()[0].getAttribute("inputtype"));
            errors.push("Illegal Connection: " + $("#" + start).text() + " -> " + $("#" + end).text())
            }
        }

    var draggables = $(".ui-draggable");

    // iterate over all nodes
    var operations = 0;
    var conditions = 0;
    for (var i = 0; i < draggables.length; i++) {
        var drag = draggables[i];
        if ($(drag).hasClass("ui-droppable") || $(drag).hasClass("unselectable")) {
            continue;
        }
        var id = $(drag).attr("id");
        var div = $("#" + id + " div")[0];
        // validate the attributes
        if (id.startsWith("Situation")) {
            errors = validateSituation(id, div, starts, ends, errors);
        } else if (id.startsWith("Operation")) {
            operations++;
            errors = validateOperation(id, div, starts, ends, errors);
        } else if (id.startsWith("Condition")) {
            conditions++;
            errors = validateCondition(id, div, starts, ends, errors);
        } else if (id.startsWith("Context")) {
            errors = validateContext(id, div, starts, ends, errors);
        }
    }
    if (operations === 0 && conditions > 1) {
        errors.push("OperationNodes are only omittable if there is only one ConditionNode.");
    }
    recognizeCycles(errors);
    if (errors.length > 0) {
        var message = "<span style='color:#ff0000'>";
        for (var i = 0; i < errors.length; i++) {
            message += errors[i] + "<br/>";
        }
        message = message.substr(0, message.length - 5);
        message += "</span>";
    } else {
        message = "<span style='color:#00ff00'>No Errors</span>"
    }
    $("#errors").html(message);
    $("#errors").show();
    return errors.length == 0;
}

/**
 * Recognizes cycles in Operations since those are the only ones, which can produce a cycle in an otherwise valid template.
 * @param errors array, that contains the error messages
 * @returns {*}
 */
function recognizeCycles(errors) {
    var ops = $('div[type^="operation"]:not(.hidden)');
    var visited = {};
    var finished = {};

    // preparations, sets all nodes to not visited and not finished (all outgoing connections tested)
    for (var i = 0; i < ops.length; i++) {
        var op = ops[i];
        var id = $(op).attr("id");
        visited[id] = false;
        finished[id] = false;
    }

    for (var i = 0; i < ops.length; i++) {
        var op = ops[i];
        // recursive depth first search.
        if (!(function dfs(o) {
                var id = $(o).attr("id");
                if (id in finished && finished[id]) {
                    return true;
                }
                if (id in visited && visited[id]) {
                    return false;
                }
                visited[id] = true;
                var parents = jsPlumb.getConnections().filter(function (connection) {
                    return connection.sourceId === id;
                });
                for (var j = 0; j < parents.length; j++) {
                    var parent = parents[j];
                    if ($("#" + parent.targetId).attr("type").startsWith("operation")) {
                        if (!dfs($("#" + parent.targetId))) {
                            return false;
                        }
                    }
                }
                finished[id] = true;
                return true;
            })(op)) {
            // add error to errors.
            errors.push("Invalid Operation Node: Cycle detected in " + $(op).attr("id"));
        }
    }
    return errors;
}

/**
 * Checks if the situation node has unset attributes.
 * @param id
 * @param div
 * @param starts
 * @param ends
 * @param errors
 * @returns {*}
 */
function validateSituation(id, div, starts, ends, errors) {
    var value = div.getAttribute("sitvalue");
    if (value == null || value == "") {
        errors.push("At least one situation does not have a name");
    } else if (ends.indexOf(id) == -1) {
        errors.push("Situation " + value + " not being used");
    } else if (ends.filter(function(end){return end === id}).length > 1) {
        errors.push("Situation " + value + " has too many inputs");
    }
    return errors;
}

/**
 * Checks if the operation node has unset attributes.
 * @param id
 * @param div
 * @param starts
 * @param ends
 * @param errors
 * @returns {*}
 */
function validateOperation(id, div, starts, ends, errors) {
    var name = div.getAttribute("oprname");
    var oprvalue = div.getAttribute("oprvalue");

    if (name == null || name == "") {
        errors.push("At least one operation does not have a name");
    } else if (oprvalue == null || oprvalue == "" || oprvalue == "null") {
        errors.push("Operation " + name + " does not have an operation value");
    } else if (starts.indexOf(id) == -1) {
        errors.push("Operation " + name + " is never propagated");
    } else if (ends.indexOf(id) == -1) {
        errors.push("Operation " + name + " has no input");
    }
    return errors;
}

/**
 * Checks if the condition node has unset attributes.
 * @param id
 * @param div
 * @param starts
 * @param ends
 * @param errors
 * @returns {*}
 */
function validateCondition(id, div, starts, ends, errors) {
    var intervalTypes = ["intervalMinEqual", "intervalMin", "intervalMaxEqual", "intervalMax"];
    var name = div.getAttribute("conditionname");
    var operator = div.getAttribute("operator");
    var value1 = div.getAttribute("sensorvalue");
    var value2 = div.getAttribute("sensorsecondvalue");
    var numIntervals = div.getAttribute("numberofintervals");

    if (name == null || name == "") {
        errors.push("At least one condition does not have a name");
    } else if (operator == null || operator == "") {
        errors.push("Condition " + name + " does not have an operator");
    } else if (value1 == null || value1 == "") {
        errors.push("Condition " + name + " does not have a value for comparison");
    } else if (operator === "between" && (value2 == null || value2 == "")) {
        errors.push("Condition " + name + " does not have a second value for comparison");
    } else if (intervalTypes.indexOf(operator) > -1 && (numIntervals == null || numIntervals == "")) {
        errors.push("Condition " + name + " misses the amount of intervals");
    } else if (starts.indexOf(id) == -1) {
        errors.push("Condition " + name + " is not used in Operations");
    } else if (ends.indexOf(id) == -1) {
        errors.push("Condition " + name + " has no input");
    } else if (ends.filter(function (end) {return end === id;}).length > 1) {
        errors.push("Condition " + name + " has too many inputs");
    }
    return errors;
}

/**
 * Checks if the context node has unset attributes.
 * @param id
 * @param div
 * @param starts
 * @param ends
 * @param errors
 * @returns {*}
 */
function validateContext(id, div, starts, ends, errors) {
    if (div.getAttribute("inputtype") === "sensor") {
        var name = div.getAttribute("contextsensor");
        var thingType = div.getAttribute("selectthingtype");
        var type = div.getAttribute("sensortype");
        var unit = div.getAttribute("sensorunit");
        var operator = div.getAttribute("operator");
        var value = div.getAttribute("value");

        if (name == null || name == "") {
            errors.push("At least one context does not have a name");
        } else if (thingType == null || thingType == "") {
            errors.push("Context " + name + " does not have a thingType");
        } else if (type == null || type == "") {
            errors.push("Context " + name + " does not have a type");
        } else if (unit == null || unit == "") {
            errors.push("Context " + name + " does not have a unit");
        } else if (operator == null || operator == ""|| operator == "null") {
            errors.push("Context " + name + " does not have a operator");
        } else if (value == null || value == "") {
            errors.push("Context " + name + " does not have a value");                        
        } else if (starts.indexOf(id) == -1) {
            errors.push("Context " + name + " is never used");
        }
    } else if (div.getAttribute("inputtype") === "static") {
        var name = div.getAttribute('staticsensor');
        var thing = div.getAttribute('staticthing');

        if (name == null || name == "") {
            errors.push("At least one context does not have a name");
        } else if (thing == null || thing == "") {
            errors.push("Context " + name + ' does not have a thing');
        }
    } else if (div.getAttribute("inputtype") === "situation") {
        var template = div.getAttribute("situationinput");
        var thing = div.getAttribute("situationthing");
        var oprneg = div.getAttribute("operationnegated");

        if (template == null || template == "") {
            errors.push("At least one situation context does not have a template");
        } else if (thing == null || thing == "") {
            errors.push("At least one context does not have a thing");
        } else if (oprneg == null || oprneg == "") {
            errors.push("Context " + thing + "." + template + " did not set the logical negation flag");
        }
    } else {
        errors.push("At least one context does not have an input type.");
    }
    return errors;
}