
function dbInit(){
$.couch.urlPrefix = "http://localhost:5984";

$.couch.db("situations").openDoc("testSave", {
    success: function(data) {
        console.log(data._id);
    },
    error: function(status) {
        console.log(status);
    }
});
}

function saveXml(){
/*var doc = {
    _id: "testSave",
    xlm: "bla bla"
};
$.couch.db("situations").saveDoc(doc, {
    success: function(data) {
        console.log(data);
    },
    error: function(status) {
        console.log(status);
    }
});*/
}
function fetchAllDocs(){
	$.couch.db("situations").allDocs(["id"],{
	    success: function(data) {
        alert(data);
    },
    error: function(status) {
        console.log(status);
    }
	});
}