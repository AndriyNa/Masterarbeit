$(document).ready(function(){

    var selected = null;
    var selectedNode = null;
    var properties = null;
    var fieldProperties = null;
   // var allowedRegex = /^([äöüÄÖÜßa-zA-Z0-9]([äöüÄÖÜßa-zA-Z0-9.]*[äöüÄÖÜßa-zA-Z0-9])?)?$/;
   var allowedRegex =  /^\S*$/;
   // @TODO correct regex
    var noWhiteSpaceRegex = /^\S*$/;


    $(".drawingArea").on("click", ".nodeTemplateSituation, .nodeTemplateOperation, .nodeTemplateContext, .nodeTemplateCondition", function() {
        // situationNode forms
        $("#sitType").val('');
        // operationNode forms
        $("#oprType").val('');
        $("#oprName").val('');
        // contextNode forms
        $("#inputtype").val('');
        // sensor
        $("#contextSensor").val('');
        $("#selectThingType").val('');
        $("#sensorType").val('');
        $("#unit").val('');
        $("#operator").val('');
        $("#value").val('');
        // static
        $("#staticSensor").val('');
        $("#thingChoiceStatic").val('');
        // situation
        $("#situationInput").val('');
        $("#thingChoice").val('');
        $("#oprNegated").val('');

        if ($(this).hasClass("nodeTemplateSituation")) {

            // Code to deselect all nodes except Situation Nodes
            $(".selected").removeClass("selected");
            $(this).addClass("selected");

            // Code to hide all Forms except Form for Situation Node
            $("#oprForm").addClass("hidden");
            $("#contextForm").addClass("hidden");
            $("#conditionForm").addClass("hidden");
            $("#sitForm").removeClass("hidden");

            // Code to display the properties when Node selected
            selectedNode = $(".selected")[0];
            fieldProperties = selectedNode.children[0].attributes;


            for (var i = 0; i < fieldProperties.length; i++) {
                if (fieldProperties[i].name == "sitvalue") {
                    document.getElementById("sitType").value = fieldProperties[i].value;
                };
            }

            // Code to process save button click on the form
            $("#sitButton").click(function() {

                var sitVal = $("#sitType").val();
                if (!(noWhiteSpaceRegex.test(sitVal))) {
                    alert("Please make sure that all values consist of alphanumeric characters or '.'.\nThe first and the last character are not allowed to be '.'");
                    return;
                }

                // Code to save the Node properties in hidden div
                selected = $(".selected")[0];

                // Code to Change the name of the node to user entered name
                var source = $(selected).attr("source");
                selected.innerHTML = sitVal + "<div id='propertyDiv'/><span style='font-size:75%'>(Situation Node)</span>";

                properties = selected.children[0];
                properties.setAttribute("sitvalue", sitVal);

                $("#sitForm").addClass("hidden");
            });

        } else if ($(this).hasClass("nodeTemplateOperation")) {

            // Code to deselect all nodes except Operation Nodes
            $(".selected").removeClass("selected");
            $(this).addClass("selected");

            // Code to hide all Forms except Form for Operation Node
            $("#sitForm").addClass("hidden");
            $("#contextForm").addClass("hidden");
            $("#conditionForm").addClass("hidden");
            $("#oprForm").removeClass("hidden");

            // Code to display the properties when Node selected
            selectedNode = $(".selected div")[0];

            var name = $(selectedNode).attr("oprname");
            var type = $(selectedNode).attr("oprvalue");


            document.getElementById("oprType").value = type == undefined || type === "undefined" ? "" : type;
            document.getElementById("oprName").value = name == undefined || name === "undefined" ? "" : name;
            

            // Code to process save button click on the form
            $("#oprButton").click(function() {
                var oprVal = $("#oprType").val();
                var oprName = $("#oprName").val();
                //&& allowedRegex.test(negated)
                if (!(allowedRegex.test(oprVal) && allowedRegex.test(oprName) )) {
                    alert("Please make sure that all values consist of alphanumeric characters or '.'.\nThe first and the last character are not allowed to be '.'");
                    return;
                }

                // Code to save the operator properties in hidden div
                selected = $(".selected")[0];

                // Code to Change the name of the node to user entered name
                var source = $(selected).attr("source");
                selected.innerHTML = oprName + "<div id='propertyDiv'/><span style='font-size:75%'>(Operation Node)</span>";

                properties = selected.children[0];
                properties.setAttribute("oprname", oprName);
                properties.setAttribute("oprvalue", oprVal);

                $("#oprForm").addClass("hidden");
            });
        } else if ($(this).hasClass("nodeTemplateCondition")) {

            $(".selected").removeClass("selected");
            $(this).addClass("selected");

            $("#sitForm").addClass("hidden");
            $("#oprForm").addClass("hidden");
            $("#contextForm").addClass("hidden");
            $("#conditionForm").removeClass("hidden");


            // Code to display the properties when Node selected
            selectedNode = $(".selected")[0];
            fieldProperties = selectedNode.children[0].attributes;


            for (var i = 0; i < fieldProperties.length; i++) {
                if (fieldProperties[i].name == "conditionname") {
                    document.getElementById("conditionType").value = fieldProperties[i].value;
                } else if (fieldProperties[i].name == "operator") {
                    document.getElementById("operator").value = fieldProperties[i].value;
                    createNewValueField(document.getElementById("operator"));
                } else if (fieldProperties[i].name == "sensorvalue") {
                    document.getElementById("value").value = fieldProperties[i].value.trim();
                } else if (fieldProperties[i].name == "sensorsecondvalue") {
                    var elem = document.getElementById("secondValue");
                    if(typeof elem !== 'undefined' && elem !== null) {
                        document.getElementById("secondValue").value = fieldProperties[i].value.trim();
                    }
                }
            }

            // Code to process save button click on the form
            $("#conditionButton").click(function() {
                var conditionVal = $("#conditionType").val();
                var opr = $("#operator").val();
                var val = $("#value").val();
                var secVal = $("#secondValue").val();
                var numbOfIntervals = $("#numberOfIntervals").val();
                var numbPattern = new RegExp(/^\d*$/);
                if (numbOfIntervals != null && !numbPattern.test(numbOfIntervals)) {
                    $("#errors").html("Please enter a number as number of intervals.");
                    return;
                }
                if (!(allowedRegex.test(conditionVal) && allowedRegex.test(opr) && allowedRegex.test(val) && allowedRegex.test(secVal))) {
                    alert("Please make sure that all values consist of alphanumeric characters or '.'.\nThe first and the last character are not allowed to be '.'");
                    return;
                }

                // Code to populate the hidden div when user saves the filled in form
                selected = $(".selected")[0];

                // Code to Change the name of the node to user entered name

                var source = $(selected).attr("source");
                selected.innerHTML = conditionVal + "<div id='propertyDiv'/><span style='font-size:75%'>(Condition Node)</span>";

                properties = selected.children[0];
                properties.setAttribute("conditionname", conditionVal);
                properties.setAttribute("operator", opr);
                properties.setAttribute("sensorvalue", val);
                properties.setAttribute("sensorsecondvalue", secVal);
                properties.setAttribute("numberOfIntervals", numbOfIntervals);

                $("#conditionForm").addClass("hidden");
            });

        } else if ($(this).hasClass("nodeTemplateContext")) {

            $(".selected").removeClass("selected");
            $(this).addClass("selected");

            $("#sitForm").addClass("hidden");
            $("#oprForm").addClass("hidden");
            $("#conditionForm").addClass("hidden");
            $("#contextForm").removeClass("hidden");


            // Code to display the properties when Node selected
            selectedNode = $(".selected")[0];
            fieldProperties = selectedNode.children[0].attributes;
            for (var i = 0; i < fieldProperties.length; i++){
                console.log(fieldProperties[i]);
            }


            for (var i = 0; i < fieldProperties.length; i++) {
                if (fieldProperties[i].name == "inputtype") {
                    var inputtype = fieldProperties[i].value;
                    document.getElementById("inputtype").value = inputtype[0].toUpperCase() + inputtype.substr(1);
                    switchStaticSensor(document.getElementById("inputtype"));
                }else if (fieldProperties[i].name == "contextsensor"){
                    document.getElementById("contextSensor").value = fieldProperties[i].value;

                }else if (fieldProperties[i].name == "sensorarray"){
                $("#sensorType").empty();
                var array = fieldProperties[i].value.split(',');
                    for (var k = 0; k < array.length; k++) {
                          var newOptionSensor = document.createElement("option");
                          newOptionSensor.textContent = array[k];
                          $("#sensorType").append(newOptionSensor);
                    };
                }else if (fieldProperties[i].name == "unitsarray"){
                    $("#unit").empty();
                    var array = fieldProperties[i].value.split(',');
                    for (var k = 0; k < array.length; k++) {
                          var newOptionSensor = document.createElement("option");
                          newOptionSensor.textContent = array[k];
                          $("#unit").append(newOptionSensor);
                    };                   
                    
                }else if (fieldProperties[i].name == "thingsarray"){
                    $("#thingChoice").empty();
                    var array = fieldProperties[i].value.split(',');
                    for (var k = 0; k < array.length; k++) {
                          var newOptionSensor = document.createElement("option");
                          newOptionSensor.textContent = array[k];
                          $("#thingChoice").append(newOptionSensor);
                    };
                    


                }else if (fieldProperties[i].name == "selectthingtype"){
                    document.getElementById("selectThingType").value = fieldProperties[i].value;
                }else if (fieldProperties[i].name == "sensortype"){
                    document.getElementById("sensorType").value = fieldProperties[i].value;
                }else if (fieldProperties[i].name == "sensorunit"){
                    document.getElementById("unit").value = fieldProperties[i].value;
                }else if (fieldProperties[i].name == "operator"){
                    document.getElementById("operator").value = fieldProperties[i].value;
                }else if (fieldProperties[i].name == "value"){
                    document.getElementById("value").value = fieldProperties[i].value;
                }else if (fieldProperties[i].name == "staticsensor"){
                    document.getElementById("staticSensor").value = fieldProperties[i].value;
                }else if (fieldProperties[i].name == "staticthing"){
                    document.getElementById("thingChoiceStatic").value = fieldProperties[i].value;
                }else if (fieldProperties[i].name == "situationinput"){
                    document.getElementById("situationInput").value = fieldProperties[i].value;
                }else if (fieldProperties[i].name == "situationthing"){
                    document.getElementById("thingChoice").value = fieldProperties[i].value;
                }else if (fieldProperties[i].name == "operationnegated"){
                    document.getElementById("oprNegated").value = fieldProperties[i].value;
                }
            }
            // Code to process save button click on the form
            $("#contextButton").click(function() {

                var sensorOptions_cache = new Array();
                $('#sensorType option').each(function() {
                    
                    sensorOptions_cache.push($(this).val());
                });
                var unitOptions_cache = new Array();
                 $('#unit option').each(function() {
                    if ($(this).val()!= ""){
                    unitOptions_cache.push($(this).val());}
                });
                var thingOptions_cache = new Array();
                 $('#thingChoice option').each(function() {
                    if ($(this).val()!= ""){
                    thingOptions_cache.push($(this).val());}
                });

                var inputtypeDIV = $('#inputtype').val();
                var contextSensorDIV = $('#contextSensor').val();
                var selectThingTypeDIV = $('#selectThingType').val();
                var sensorTypeDIV = $("#sensorType").val();
                var unitDIV = $("#unit").val();
                var operatorDIV = $("#operator").val();
                var valueDIV = $("#value").val();
                var staticSensorDIV = $("#staticSensor").val();
                var thingChoiceStaticDIV = $("#thingChoiceStatic").val();
                var situationInputDIV = $("#situationInput").val();
                var thingChoiceDIV = $("#thingChoice").val();
                var oprNegatedDIV = $("#oprNegated").val();
                
                /*
                var rmp = inputtype == 'Situation'? $("#situationRmp").val() : $("#contextRMP").val();
                var thing = inputtype == 'Situation'? $("#thingChoice").val() : $("#selectThingType").val();
                var contextVal = inputtype == "Static" ? $("#staticSensor").val() : $("#contextSensor").val(); 
                var template = $("#situationInput").val();
                unit = unit == null ? "" : unit;
                */
                if (!(allowedRegex.test(inputtypeDIV))){
                    alert("Please select an input type that consists of alphanumeric characters or '.'.\nThe first and the last character are not allowed to be '.'");
                    return;
                }
                // TODO: no unit-regex : && allowedRegex.test(unitDIV)
                else if (inputtypeDIV == "Sensor"){
                    if (!(allowedRegex.test(contextSensorDIV) 
                    && noWhiteSpaceRegex.test(selectThingTypeDIV) && allowedRegex.test(sensorTypeDIV)
                    && allowedRegex.test(operatorDIV)
                    && allowedRegex.test(valueDIV))){
                        alert("Please make sure that all values consist of alphanumeric characters or '.'.\nThe first and the last character are not allowed to be '.'");
                        return;
                    }
                }else if (inputtypeDIV == "Static"){
                    if (!(allowedRegex.test(staticSensorDIV) && noWhiteSpaceRegex.test(thingChoiceStaticDIV))){
                        alert("Please make sure that all values consist of alphanumeric characters or '.'.\nThe first and the last character are not allowed to be '.'");
                        return;
                    }
                }else if (inputtypeDIV == "Situation"){
                    if(!(allowedRegex.test(situationInputDIV)
                    && noWhiteSpaceRegex.test(thingChoiceDIV) && allowedRegex.test(oprNegatedDIV))) {
                        alert("Please make sure that all values consist of alphanumeric characters or '.'.\nThe first and the last character are not allowed to be '.'");
                        return;
                    }
                }

                // Code to populate the hidden div when user saves the filled in form
                selected = $(".selected")[0];

                // Code to Change the name of the node to user entered name
                if (situationInputDIV == 'Choose a file'){situationInputDIV = '';}
                var contextVal = inputtypeDIV == "Static" ? $("#staticSensor").val() : $("#contextSensor").val(); 
                var name = inputtypeDIV == "Situation" ? "Sit::" + situationInputDIV : (contextVal);
                var source = $(selected).attr("source");
                var displayCondition = (operatorDIV == "lowerThan" ? "<" : ">") + " " + valueDIV;
                // Display Properties.
                if (inputtypeDIV == "Sensor"){
                selected.innerHTML = name + "<div id='propertyDiv'/><span style='font-size:75%'>(Context Node)</span>" +
                 "<br><br><div id='propertyDiv'/><span style='font-size:150%'>" + displayCondition + "</span>" + 
                 "<span style='font-size:60%'>" + " " + unitDIV + "</span>" ;}
                 else{
                     selected.innerHTML = name + "<div id='propertyDiv'/><span style='font-size:75%'>(Context Node)</span>";
                 }

                properties = selected.children[0];
                if (inputtypeDIV.toLowerCase() == 'sensor' || inputtypeDIV == '') {
                    properties.setAttribute('inputtype', 'sensor');
                    properties.setAttribute('contextsensor', contextSensorDIV);
                    properties.setAttribute('selectthingtype', selectThingTypeDIV);
                    properties.setAttribute("sensorarray", sensorOptions_cache);
                    properties.setAttribute("unitsarray", unitOptions_cache);
                    properties.setAttribute("sensortype", sensorTypeDIV);
                    properties.setAttribute("sensorunit", unitDIV);
                    properties.setAttribute("operator", operatorDIV);
                    properties.setAttribute("value", valueDIV);                  
                } else if (inputtypeDIV.toLowerCase() == 'static') {
                    properties.setAttribute("staticsensor", staticSensorDIV);
                    properties.setAttribute("staticthing", thingChoiceStaticDIV);
                    properties.setAttribute('inputtype', 'static');
                } else if (inputtypeDIV.toLowerCase() == 'situation') {
                    properties.setAttribute("situationinput", situationInputDIV);
                    properties.setAttribute("thingsarray", thingOptions_cache);
                    properties.setAttribute("situationthing", thingChoiceDIV);
                    properties.setAttribute("operationnegated", oprNegatedDIV)
                    properties.setAttribute("inputtype", "situation");
                }

                $("#contextForm").addClass("hidden");
            });
        }
    });
});

function escapeRegExp(text) {
  return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
}