function getSituationTemplateAsXML(templateName) {
    var i, j;
    var cons;
    var id = "";
    var xmlw = new XMLWriter("utf-8");
    xmlw.writeStartDocument();
    xmlw.writeStartElement("SituationTemplate");
    xmlw.writeAttributeString("name", templateName);
    xmlw.writeAttributeString("id", templateName);
    xmlw.writeAttributeString("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
    xmlw.writeAttributeString("xsi:noNamespaceSchemaLocation", "situation_template_one_context.xsd");
    xmlw.writeStartElement("Situation");

    var situations = $("div[type|='situationnode']:not(.hidden)");
    var operations = $("div[type|='operationnode']:not(.hidden)");
    //var conditions = $("div[type|='conditionnode']:not(.hidden)");
    var contexts = $("div[type|='contextnode']:not(.hidden)");

    // There can only be one situation so the code is loop over one element.
    for (i = 0; i < situations.length; i++) {
        var sit = situations[i];
        id = $(sit).attr("id");
        var sitname = $("#" + id + " div").attr("sitvalue");
        xmlw.writeStartElement("situationNode");
        xmlw.writeAttributeString("id", id);
        xmlw.writeAttributeString("name", sitname);
        xmlw.writeEndElement();
    }

    for (i = 0; i < operations.length; i++) {
        var op = operations[i];
        id = $(op).attr("id");
        var opname = $("#" + id + " div").attr("oprname");
        var optype = $("#" + id + " div").attr("oprvalue");

        xmlw.writeStartElement("operationNode");
        xmlw.writeAttributeString("id", id);
        xmlw.writeAttributeString("name", opname);
        cons = jsPlumb.getConnections().filter(function (con) {
            return con.sourceId === id;
        });
        for (j = 0; j < cons.length; j++) {
            xmlw.writeStartElement("parent");
            xmlw.writeAttributeString("parentID", cons[j].targetId);
            xmlw.writeEndElement();
        }
        xmlw.writeElementString("type", optype.toLowerCase());
        xmlw.writeEndElement();
    }
/*
    for (i = 0; i < conditions.length; i++) {
        var condition = conditions[i];
        id = $(condition).attr("id");
        var conType = $("#" + id + " div").attr("operator");
        var conName = $("#" + id + " div").attr("conditionname");
        var numIntervals = $("#" + id + " div").attr("numberofintervals");
        var value1 = $("#" + id + " div").attr("sensorvalue");
        var value2 = $("#" + id + " div").attr("sensorsecondvalue");

        xmlw.writeStartElement("conditionNode");
        xmlw.writeAttributeString("id", id);
        xmlw.writeAttributeString("name", conName);
        if (conType.startsWith("interval")) {
            xmlw.writeAttributeString("xsi:type", "tTimeNode");
            xmlw.writeElementString("amountIntervals", numIntervals);
        }
        xmlw.writeElementString("opType", conType);
        xmlw.writeStartElement("condValues");
        xmlw.writeElementString("value", value1);
        if (conType === "between") {
            xmlw.writeElementString("value", value2);
        }
        //condValues
        xmlw.writeEndElement();
        cons = jsPlumb.getConnections().filter(function (con) {
            return con.sourceId === id;
        });
        for (j = 0; j < cons.length; j++) {
            xmlw.writeStartElement("parent");
            xmlw.writeAttributeString("parentID", cons[j].targetId);
            xmlw.writeEndElement();
        }
        //conditionNode
        xmlw.writeEndElement();
    }*/
        var thingTypeCollection = new Array();
    for (i = 0; i < contexts.length; i++) {

        var context = contexts[i];
        id = $(context).attr("id");

        var contextName;
        var inputtype = $("#" + id + ' div').attr('inputtype');
        var sensorType;
        var measureName;
        var sitinput;
        var thingType;
        var op;
        var value;
        var thing;
        var negated;

        if (inputtype == "sensor") {
            contextName = $("#" + id + " div").attr("contextsensor");
            thingType = $("#" + id + " div").attr("selectthingtype");            
            sensorType = $("#" + id + " div").attr("sensortype");
            measureName = $("#" + id + " div").attr("sensorunit");
            op = $("#" + id + " div").attr("operator");
            value = $("#" + id + " div").attr("value");
            thingTypeCollection.push(thingType);
            
            xmlw.writeStartElement("contextNode");
            xmlw.writeAttributeString("id", id);
            xmlw.writeAttributeString("name", contextName);
            xmlw.writeElementString('inputType', inputtype);
            xmlw.writeElementString("thingType", thingType);
            xmlw.writeElementString("sensorType", sensorType);
            xmlw.writeElementString("measureName", measureName);
            xmlw.writeElementString('opType', op);
            xmlw.writeElementString('value', value);
            
            
            // was muss da stehen?
        } else if (inputtype == "static") {
            contextName = $("#" + id + " div").attr("staticsensor");                        
            thing = $("#" + id + " div").attr("staticthing");

           
            xmlw.writeStartElement("contextNode");
            xmlw.writeAttributeString("id", id);
            xmlw.writeAttributeString("name", contextName);
            xmlw.writeElementString('inputType', inputtype);
            xmlw.writeElementString('thing', thing);
            

        } else if (inputtype == "situation") {
            contextName = $("#" + id + " div").attr("situationinput");
            sitinput = $("#" + id + " div").attr("situationinput");
            thing = $("#" + id + " div").attr("situationthing");
            negated = $("#" + id + " div").attr("operationnegated");

           
            xmlw.writeStartElement("contextNode");
            xmlw.writeAttributeString("id", id);
            xmlw.writeAttributeString("name", contextName);
            xmlw.writeElementString('inputType', inputtype);
            xmlw.writeElementString('situationInput', sitinput);
            xmlw.writeElementString("thing", thing);
            xmlw.writeElementString('negated', negated);
        }

        cons = jsPlumb.getConnections().filter(function (con) {
            return con.sourceId === id;
        });

        for (j = 0; j < cons.length; j++) {
            xmlw.writeStartElement("parent");
            xmlw.writeAttributeString("parentID", cons[j].targetId);
            xmlw.writeEndElement();
        }
        xmlw.writeEndElement();
    }
    xmlw.writeEndElement("Situation");
    xmlw.writeStartElement("thingTypes");
    if (thingTypeCollection.length != 0){
        for (var k = 0; k < thingTypeCollection.length;k++){
            xmlw.writeElementString('thingType', thingTypeCollection[k]);
        }
    }else{
        xmlw.writeStartElement("thingType");
        xmlw.writeEndElement("thingType");
    }
    xmlw.writeEndElement("thingTypes");
    xmlw.writeEndElement();
    xmlw.writeEndDocument();

    return xmlw.flush();
}
	