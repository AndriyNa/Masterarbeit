/**
 * Function called when the 'Load'-Button is pressed
 * @return {[load()-function]}
 */
function loadBtn() {
	if (loadCnt < 1){
	   prepareSelectionList("selectTempl", 'situationtemplates');
    }
	clearAll();
    $("#selectTempl").val('Choose a file');
    $("#loadbox").toggle();
    loadbox.setAttribute("indrawingarea", "true");
    if (loadCnt < 1) {
        load();
    };
}



function prepareSelectionList(input, dbname){

	var IDs = getDocIDs(dbname);
	//console.log (IDs);
	
	var select = document.getElementById(input);
	
	for(var i = 0; i < IDs.length; i++) {
		var opt = IDs[i];
		var el = document.createElement("option");
		el.textContent = opt;
		el.value = opt;
		select.appendChild(el);
	}

}


function getDocIDs(dbname){
   var idArr = new Array ();
   
    /*
    for debugging
    console.log('http://localhost:5984/' + dbname + '/_all_docs');
    */
   
   $.ajax({
        type: "GET",
        url: 'http://localhost:5984/' + dbname + '/_all_docs',
        async: false,
            success : function(data){
                var data = JSON.parse(data);
                $.each(data.rows, function(i, v) {
                    idArr.push(v.id);
                return;});
            }
   });
   return idArr;
}

var loadCnt = 0;
var selTempl = 'Choose a file';

function load() {
    $(document).ready(function(){
        var xmlDoc;
        loadCnt++;
        $("#openTempl").click(function() {
            clearAll();
            selTempl = $("#selectTempl").children(':selected').text();
            console.log("Currently selected template: " + selTempl);
            console.log("Currentl load count: " + loadCnt);
            if (selTempl != "Choose a file"){
                 $.ajax({
                    async: false,
                    type: "GET",
                    url: 'http://localhost:5984/situationtemplates/' + selTempl +'/attachment',
                    dataType: "text",
                        success : function(data){
                            xmlDoc = data;
                        return;}

                    });

                       
           openSitTempl(xmlDoc);
            } 
        });
        
        /**
        $.ajax({
            type: "GET",
            url: "load",
            data: {test: "Datei Laden"}
        }).done(function( msg ) {
            // code to iterate situation templates, display choices in a list
            var templArray = JSON.parse(msg);
            for (var i=0; i < templArray.length; i++) {
                var newOption = document.createElement("option");
                newOption.textContent = templArray[i];
                $("#selectTempl").append(newOption);
            }
            $("#openTempl").click(function() {
                clearAll();
                var selTempl = $("#selectTempl").children(':selected').text();
                openSitTempl(selTempl);
            });
        });*/
    });
};


function sitAsInputOptions(){
prepareSelectionList("sitTempList");}

function sitAsInput(){
	alert("TODO: logic for selection a situation template from db via GET request" )
}

/**
 * @todo [Exchange the hardcoded connection parts like url, server etc.]
 * url: config.protocol + "://" + config.server + ":" + config.port + "/situationtemplates/ByID",
 */
function save() {

    var savename = prompt("Under which name should the template be saved?", "NoName");

    if (savename == "") {
        alert("Geben sie einen Namen ein!");
    } else if (savename === null) {
        console.log("Saving canceled.");
    return;      
    }

    else {
        var xml = getSituationTemplateAsXML(savename);
        xml = xml.replace(/\n/g, '').replace(/\r/g, '').replace(/\t/g, '');
        var thingTypes = retrieveThingTypes();
        
        $.ajax({
           type: 'post',
		   url: 'http://localhost:5984/situationtemplates',
           contentType: 'application/json',
           data: JSON.stringify({_id:savename, thingTypes:thingTypes}),
           success: function() {
				var _rev = get_rev(savename);
                $.ajax({
                    async: false,
                    type: "put",
                    url: 'http://localhost:5984/situationtemplates/' + savename + "/attachment?rev=" + _rev,
                    contentType: 'application/xml',
                    data: xml,
                    success: function() {
                        alert("Template successfully created");
                    },
                    error: function () {
                         alert("An Error occured. Document could not be stored.");
                     }
                });
            },
			
            error: function () {
                alert("An Error occured. Document could not be stored.");
            }
        });
    }
}


function get_rev(docId){
   var response = '';
   $.ajax({
        type: "get",
        url: 'http://localhost:5984/situationtemplates/' + docId,
        async: false,
            success : function(data)
         {
             var data = JSON.parse(data);
             response = data._rev;
         }
    });
   return response;
}


function startRec() {
    if (!validate()) {
        $("errors").html($("#errors").html() + "<br>Please solve all problems above, before starting recognition");
        return;
    }

    var name = prompt("Under which name should the template be saved?", "NoName");
    while (name === "") {
        alert("Please give a name");
        name = prompt("Under which name should the template be saved?", "NoName");
    }
    var contexts = $("[type='contextnode']").not(".hidden");
    var mapping = new Array(contexts.length);
    for (var i = 0; i < contexts.length; i++) {
        var con = contexts[i];
        mapping[i] = prompt("Für welche Sensoren soll der Context \"" + $(con.children[0]).attr("contextname") + "\" verwendet werden?", "")
    }
    for (var i = 0; i < mapping.length; i++) {
        var result1 = mapping[i].split(",");
        mapping[i] = [];
        for (var j = 0; j < result1.length; j++) {
            var result2 = result1[j].trim();
            if (result2 !== "") {
                mapping[i].push(result2);
            }
        }
    }
    if (!mapping) {
        mapping = [];
    }

    $.ajax({
        "type": "POST",
        "url": "StartRec",
        "data": {
            "xml":getSituationTemplateAsXML(name).replace(/\r/g, "").replace(/\n/g, "").replace(/\t/g, ""),
            "mapping": mapping
        }
    }).done(function( msg ) {
        alert(msg)

    });
};

function clearAll() {
    var drawingArea = document.getElementById('drawingArea');
    loadCnt = 0;
    selTempl = 'Choose a file';
};

function exportXML() {

    if (!validate()) {
        $("#errors").html($("#errors").html() + "<br>Please solve all problems above, before you export as XML");
        return;
    }

    var exportname = prompt("Under which name should the template be exported?", "NoName");

    if (exportname == "" || exportname == "null") {
        alert("Please give a name!");
    } else {
        // Saving xml file locally
        var sitTemplateString = getSituationTemplateAsXML(exportname);
        var blob = new Blob([sitTemplateString], {type: "text/xml;charset=utf-8"});
        // saveAs(blob, "situationTemplate.xml");
        saveAs(blob, exportname+".xml");
    }
};

function openSitTempl(xmlDoc) {
    $(document).ready(function(){
        $("#loadbox").hide();
        parseAndTraverseXML(xmlDoc);
    });
}

var sitInputCounter = 0;
function sitTemplInput(){
    if (sitInputCounter < 1){
    prepareSelectionList("situationInput", 'situationtemplates');
    sitInputCounter++;
    }

}
/*
var thingChoiceCounter = 0;
function thingChoiceInput(){
    if (thingChoiceCounter < 1){
    prepareSelectionList("thingChoice", 'things');
    thingChoiceCounter++;
    }
}*/

var thingChoiceStaticCounter = 0;
function thingChoiceStaticInput(){
    if (thingChoiceStaticCounter < 1){
    prepareSelectionList("thingChoiceStatic", 'things');
    thingChoiceStaticCounter++;
    }

}

var thingTypeCounter = 0;
function thingTypeSelection(){
    if (thingTypeCounter < 1){
    prepareSelectionList("selectThingType", 'thingtypes');
    thingTypeCounter++;
    }

}

function retrieveThingTypes(){
    var contexts = $("div[type|='contextnode']:not(.hidden)");
     var thingTypeCollection = new Array();
    for (i = 0; i < contexts.length; i++) {
        var thingType;
        var context = contexts[i];
        id = $(context).attr("id");
        var inputtype = $("#" + id + ' div').attr('inputtype');
        if (inputtype == "sensor") {
            thingType = $("#" + id + " div").attr("selectthingtype");
            thingTypeCollection.push(thingType);
        }
    }
    return thingTypeCollection;
}