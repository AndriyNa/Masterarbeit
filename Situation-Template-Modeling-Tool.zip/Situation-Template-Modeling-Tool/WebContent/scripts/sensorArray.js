
/*This Array contains the sensors and their respective units as array. 
 * Inorder to add a new sensor and its respective array of units please make an entry hier */


var sensorArray = "";
var counterThingType = 0;

function populate(sensorArray){
if (counterThingType > 0){
    $("#sensorType").empty();
    $("#sensorType").append("<option value=''></option>");
}
  
  for (var i = 0; i < sensorArray.length; i++) {
    
	  var newOptionSensor = document.createElement("option");
	  newOptionSensor.textContent = sensorArray[i].sensorName;
	  $("#sensorType").append(newOptionSensor);
};
}

function getSensorInfo(Type){
  counterThingType++;
  var sensors = new Array ();
  if (Type != ""){
   $.ajax({
        type: "GET",
        url: 'http://localhost:5984/thingtypes/' + Type,
        async: false,
            success : function(data){
                var data = JSON.parse(data);
                $.each(data.Sensors, function(i, v) {
                    sensors.push(v);
                return;});
            }
   });
   console.log(sensors);
   }
   else {
    sensors = [];
    console.log(sensors);
   }
   sensorArray = sensors;
   populate(sensors);
   return sensors;
}

function getSensorArray(){
  return sensorArray;
}